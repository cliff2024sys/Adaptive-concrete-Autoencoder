import sys
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from pandas.api.types import is_string_dtype, is_numeric_dtype
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, mean_squared_error



def string_to_category(df):
    for colName, colData in df.items():
        if is_string_dtype(colData):
            df[colName] = colData.astype("category").cat.as_ordered()


def fill_empty_col(df):
    for name, col in df.items():
        if is_numeric_dtype(col):
            df[name] = col.fillna(col.median())


def normalize_data(df):
    scaler = StandardScaler()
    for name, col in df.items():
        if is_numeric_dtype(col):
            df[name] = scaler.fit_transform(pd.DataFrame(df[name]))


def category_to_integer(df):
    for name, col in df.items():
        if not is_numeric_dtype(col):
            df[name] = pd.Categorical(col).codes + 1


def changeTargetToBinary(name):
    if name != "normal":
        name = "attacks"
    return name


def important_features(x_df, selectedModel):
    column_names = x_df.columns.values.tolist()
    # Print the name and the importance of each feature
    return [
        column_names[index]
        for index in selectedModel.get_support(indices=True)
    ]


def modelTesting(y_test, y_pred):
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    f_score = f1_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    mean_score = mean_squared_error(y_test, y_pred)
    return pd.DataFrame({"Accuracy": accuracy, "Precision": precision, "F score": f_score, "Recall": recall, "Mean Square" : mean_score}, index=[0])


def save_df_as_heatmap_image(df, path):
    plot = sns.heatmap(df, annot=True, cbar=False,
                       fmt='g')
    plt.tick_params(axis='both', which='major', labelsize=10,
                    labelbottom=False, bottom=False, top=False, left=False, labeltop=True)
    fig = plot.get_figure()
    fig.savefig(path)
    
    
def join_dataframe(*args, **kwargs):
    results = pd.concat(args[:-1])
    index_names = args[len(args) - 1]
    results.index = index_names
    return save_df_as_heatmap_image(results, "./images/results")


def create_df_table(data, col_width=3.0, 
                    row_height=0.625,font_size=14, header_color='#40466e', row_colors=['#f1f1f2', 'w'], edge_color='w', bbox=[0, 0, 1, 1], header_columns=0, ax=None,**kwargs):
    if ax is None:
        size = (np.array(data.shape[::-1]) + np.array([0, 1])
                ) * np.array([col_width, row_height])
        fig, ax = plt.subplots(figsize=size)
        ax.axis('off')
    df_table = ax.table(cellText=data.values, bbox=bbox,
                        colLabels=data.columns, **kwargs)
    df_table.auto_set_font_size(False)
    df_table.set_fontsize(font_size)

    for k, cell in df_table._cells.items():
        cell.set_edgecolor(edge_color)
        if k[0] == 0 or k[1] < header_columns:
            cell.set_text_props(weight='bold', color='w')
            cell.set_facecolor(header_color)
        else:
            cell.set_facecolor(row_colors[k[0] % len(row_colors)])
    return ax.get_figure(), ax


def draw_and_export_table(df, path):
    fig, ax = create_df_table(df, col_width=4.5)
    fig.savefig(path)
    
    
def confusionMatrix(df, path, name):
    fig, ax = plt.subplots(figsize=(10, 6))
    #annot=True to annotate cells, ftm='g' to disable scientific notation
    sns.heatmap(df, annot=True, fmt='g', ax=ax)

    # labels, title and ticks
    ax.set_xlabel('Predicted labels')
    ax.set_ylabel('True labels')
    ax.set_title(f'Confusion Matrix of {name} Classifier')
    ax.xaxis.set_ticklabels(['Attacks', 'Normal'], fontsize=13)
    ax.yaxis.set_ticklabels(['Attacks', 'Normal'], fontsize=13)
    fig.savefig(path)

        